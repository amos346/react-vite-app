import express from 'express';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function startServer() {
  const app = express();
  app.use(express.json());

  // In-memory storage for demo and persistent simulation
  const reservations: any[] = [];
  const contacts: any[] = [];

  // API Routes
  app.post('/api/reservations', (req, res) => {
    try {
      const data = req.body;
      if (!data.fullName || !data.phone || !data.email || !data.date || !data.time || !data.guests) {
        return res.status(400).json({ success: false, error: 'Missing required reservation fields.' });
      }

      const newReservation = {
        id: 'RES-' + Math.floor(100000 + Math.random() * 900000),
        ...data,
        createdAt: new Date().toISOString(),
        status: 'confirmed'
      };

      reservations.push(newReservation);
      console.log('New Reservation Saved:', newReservation);

      return res.json({
        success: true,
        message: 'Table reservation successfully requested and confirmed!',
        reservation: newReservation
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  app.get('/api/reservations', (req, res) => {
    res.json({ success: true, count: reservations.length, reservations });
  });

  app.post('/api/contact', (req, res) => {
    try {
      const data = req.body;
      if (!data.name || !data.email || !data.message) {
        return res.status(400).json({ success: false, error: 'Missing required contact fields.' });
      }

      const newContact = {
        id: 'MSG-' + Math.floor(100000 + Math.random() * 900000),
        ...data,
        createdAt: new Date().toISOString()
      };

      contacts.push(newContact);
      console.log('New Contact Message:', newContact);

      return res.json({
        success: true,
        message: 'Thank you for reaching out! We have received your message and will respond shortly.',
        contact: newContact
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  // Vite integration or static file serving
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  } else {
    // Development mode with Vite middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true }
    });
    app.use(vite.middlewares);
  }

  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
