import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { MenuSection } from './components/MenuSection';
import { SpecialOffers } from './components/SpecialOffers';
import { GallerySection } from './components/GallerySection';
import { Reservations } from './components/Reservations';
import { Testimonials } from './components/Testimonials';
import { LocationHours } from './components/LocationHours';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { WhatsAppWidget } from './components/WhatsAppWidget';
import { BackToTop } from './components/BackToTop';
import { OnlineOrderingCart } from './components/OnlineOrderingCart';
import { PrivacyModal } from './components/PrivacyModal';
import { ImageManagerModal } from './components/ImageManagerModal';
import { CartItem, MenuItem } from './types';
import { menuItems as initialMenuItems } from './data/restaurantData';

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [privacyModalType, setPrivacyModalType] = useState<'privacy' | 'terms' | null>(null);
  const [imageManagerOpen, setImageManagerOpen] = useState(false);
  const [customMenuItems, setCustomMenuItems] = useState<MenuItem[]>(() => {
    const saved = localStorage.getItem('savora_custom_menu');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return initialMenuItems;
  });

  const handleAddToCart = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((ci) => ci.item.id === item.id);
      if (existing) {
        return prev.map((ci) =>
          ci.item.id === item.id ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [...prev, { item, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (itemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((ci) => {
          if (ci.item.id === itemId) {
            const newQty = ci.quantity + delta;
            return newQty > 0 ? { ...ci, quantity: newQty } : null;
          }
          return ci;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setCart((prev) => prev.filter((ci) => ci.item.id !== itemId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleUpdateItemImage = (itemId: string, newImageUrl: string) => {
    setCustomMenuItems((prev) => {
      const updated = prev.map((i) => (i.id === itemId ? { ...i, image: newImageUrl } : i));
      localStorage.setItem('savora_custom_menu', JSON.stringify(updated));
      return updated;
    });
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const navigateToReservation = () => {
    const el = document.getElementById('reservation');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const navigateToMenu = () => {
    const el = document.getElementById('menu');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#1A2E22] selection:bg-[#D4AF37] selection:text-[#1A2E22]">
      {/* Navbar */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onNavigateReservation={navigateToReservation}
        onOpenImageManager={() => setImageManagerOpen(true)}
      />

      {/* Main Content Sections */}
      <main>
        <Hero
          onNavigateReservation={navigateToReservation}
          onNavigateMenu={navigateToMenu}
        />
        <About />
        <MenuSection
          menuItems={customMenuItems}
          onAddToCart={handleAddToCart}
          cartItemsCount={totalCartCount}
          onOpenCart={() => setIsCartOpen(true)}
        />
        <SpecialOffers onNavigateReservation={navigateToReservation} />
        <GallerySection />
        <Reservations />
        <Testimonials />
        <LocationHours />
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer
        onOpenPrivacy={(type) => setPrivacyModalType(type)}
        onNavigateReservation={navigateToReservation}
        onOpenImageManager={() => setImageManagerOpen(true)}
      />

      {/* Interactive Widgets */}
      <WhatsAppWidget
        onNavigateReservation={navigateToReservation}
        onNavigateMenu={navigateToMenu}
      />
      <BackToTop />

      {/* Shopping Cart Drawer */}
      <OnlineOrderingCart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Privacy & Terms Modal */}
      <PrivacyModal
        type={privacyModalType}
        onClose={() => setPrivacyModalType(null)}
      />

      {/* Image Manager Modal for Owner */}
      <ImageManagerModal
        isOpen={imageManagerOpen}
        onClose={() => setImageManagerOpen(false)}
        menuItems={customMenuItems}
        onUpdateItemImage={handleUpdateItemImage}
      />
    </div>
  );
}
